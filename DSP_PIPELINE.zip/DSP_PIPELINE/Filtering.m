
%Filtering the signal, using the matlab function filter.

FilteredSignal = filter(Bn,An,Signal);
